//
//  DDMCDemoCenterViewController.m
//  MMDCDemo
//
//  Created by 时间沙漏iOS on 2017/2/17.
//  Copyright © 2017年 litao. All rights reserved.
//

#import "DDMCDemoCenterViewController.h"
#import "UIViewController+MMDrawerController.h"
#import "MMDrawerBarButtonItem.h"

@interface DDMCDemoCenterViewController ()

@end

@implementation DDMCDemoCenterViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.mm_drawerController.openDrawerGestureModeMask = MMOpenDrawerGestureModeAll;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"DDMCDemo";
    
    //左边增加一个menu导航按钮
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"menu"] style:(UIBarButtonItemStylePlain) target:self action:@selector(leftBtn)];
    
    //右边增加一个按钮
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"contact"] style:(UIBarButtonItemStylePlain) target:self action:@selector(rightBtn)];
    
    // Do any additional setup after loading the view.
}

- (void)leftBtn{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:^(BOOL finished) {
        
    }];
}

- (void)rightBtn{
    [self.mm_drawerController toggleDrawerSide:(MMDrawerSideRight) animated:YES completion:^(BOOL finished) {
        
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end



















