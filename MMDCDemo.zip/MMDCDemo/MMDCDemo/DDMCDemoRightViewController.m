//
//  DDMCDemoRightViewController.m
//  MMDCDemo
//
//  Created by 时间沙漏iOS on 2017/2/17.
//  Copyright © 2017年 litao. All rights reserved.
//

#import "DDMCDemoRightViewController.h"
#import "UIViewController+MMDrawerController.h"
#import "MyViewController.h"


@interface DDMCDemoRightViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *menuArray;
}

@end

@implementation DDMCDemoRightViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor yellowColor];
    self.title = @"drawer-right";
    NSString *plist = [[NSBundle mainBundle] pathForResource:@"rightmenuData" ofType:@"plist"];
    menuArray = [NSMutableArray arrayWithContentsOfFile:plist];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 10;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(cell == nil  ){
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
    }
    tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];

    cell.textLabel.text = [menuArray[indexPath.row] objectForKey:@"title"];
    cell.textLabel.textAlignment = NSTextAlignmentCenter;
    cell.backgroundColor = [UIColor yellowColor];
    return cell;
    
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    MyViewController *MyVC = [[MyViewController alloc]init];
    MyVC.title = [menuArray[indexPath.row] objectForKey:@"title"];
    UINavigationController* nav = (UINavigationController*)self.mm_drawerController.centerViewController;
    [nav pushViewController:MyVC animated:NO];
    
    //当我们push成功之后，关闭我们的抽屉
    [self.mm_drawerController closeDrawerAnimated:YES completion:^(BOOL finished) {
        
        //设置打开抽屉模式为MMOpenDrawerGestureModeNone，也就是没有任何效果。
        [self.mm_drawerController setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeNone];
    }];
}


@end

















